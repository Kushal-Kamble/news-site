1...USER.PHP sequence vise code to better understand

2...add-user.php

3...update-user.PHP

4...delete-user.PHP

5...paginatiom   users.php


